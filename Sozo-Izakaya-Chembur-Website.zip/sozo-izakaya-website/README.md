# Sozo Izakaya — Chembur

A responsive restaurant website built with:
- HTML5
- CSS3
- Vanilla JavaScript
- Google Fonts
- Uploaded restaurant/food photography

## Run
Open `index.html` in any modern browser.

## Customize
- Replace images in `images/`
- Update menu copy in `index.html`
- Update the reservation phone number in the `tel:` link
- Add the exact restaurant address, phone, timings and social links when available
